%% Intro to Matlab

% (2) Basic types in Matlab

A = [1 2; 3 4]              % Creates a 2x2 matrix
                            % The simplest way to create a matrix is
                             % to list its entries in square brackets.
                             % The ";" symbol separates rows;
                             % the (optional) "," separates columns.

N = 5                        % A scalar
v = [1 0 0]                  % A row vector
v = [1; 2; 3]                % A column vector
v = v'                       % Transpose a vector (row to column or 
                             %   column to row)
v = 1:.5:3                   % A vector filled in a specified range: 

v = pi*[-4:4]/4              %   [start:stepsize:end]
                             %   (brackets are optional)
v = []                       % Empty vector

clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (B) Creating special matrices: 1ST parameter is ROWS,
%   2ND parameter is COLS 

m = zeros(2, 3)              % Creates a 2x3 matrix of zeros
v = ones(1, 3)               % Creates a 1x3 matrix (row vector) of ones
m = eye(3)                   % Identity matrix (3x3)
v = rand(3, 1)               % Randomly filled 3x1 matrix (column 
                             % vector); see also randn

                             % But watch out:
m = zeros(3)                 % Creates a 3x3 matrix (!) of zeros

clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (C) Indexing vectors and matrices.
% Warning: Indices always start at 1 and *NOT* at 0!

v = [1 2 3]
v(3)                         % Access a vector element 

clc
m = [1 2 3 4; 5 7 8 8; 9 10 11 12; 13 14 15 16]
m(1, 3)                      % Access a matrix element
                             %       matrix(ROW #, COLUMN #)
m(2, :)                      % Access a whole matrix row (2nd row)
m(:, 1)                      % Access a whole matrix column (1st column)

m(1, 1:3)                    % Access elements 1 through 3 of the 1st row

m(2:3, 2)                    % Access elements 2 through 3 of the 
                             %   2nd column
m(2:end, 3)                  % Keyword "end" accesses the remainder of a
                             %   column or row
clc
m = [1 2 3; 4 5 6]     
size(m)                      % Returns the size of a matrix
size(m, 1)                   % Number of rows
size(m, 2)                   % Number of columns

m1 = zeros(size(m))          % Create a new matrix with the size of m

who                          % List variables in workspace

whos                         % List variables w/ info about size, type, etc.


clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (3) Simple operations on vectors and matrices
% vectors/matrices are to be added, subtracted, or element-wise
% multiplied or divided, they must have the same size.

a = [1 2 3 4]'              % A column vector
2 * a                        % Scalar multiplication
a / 4                        % Scalar division
b = [5 6 7 8]'              % Another column vector

a + b                        % Vector addition
a - b                        % Vector subtraction
a .^ 2                       % Element-wise squaring (note the ".")
a .* b                       % Element-wise multiplication (note the ".")
a ./ b                       % Element-wise division (note the ".")

log([1 2 3 4])               % Element-wise logarithm
round([1.5 2; 2.2 3.1])      % Element-wise rounding to nearest integer

clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (B) Vector Operations

% Built-in Matlab functions that operate on vectors

a = [1 4 6 3]                % A row vector
sum(a)                       % Sum of vector elements
mean(a)                      % Mean of vector elements
var(a)                       % Variance of elements
std(a)                       % Standard deviation

clc