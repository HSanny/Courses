%% Loops and conditional statements
%% Always avoid loops, loops are slow.

% Syntax of control flow statements:
% 

% for VARIABLE = EXPR
%     STATEMENT
%      ...
%     STATEMENT
% end 
%
%   EXPR is a vector here, e.g. 1:10 or -1:0.5:1 or [1 4 7]
 
% while EXPRESSION
%     STATEMENTS
% end
 
% if EXPRESSION
%     STATEMENTS 
% elseif EXPRESSION
%     STATEMENTS
% else
%     STATEMENTS
% end

%   The operators are <, >, <=, >=, ==, ~=  (almost like in C(++))

for i=1:2:7                  % Loop from 1 to 7 in steps of 2
  i                          % Print i
end

for i=[5 13 -1]              % Loop over given vector
  if (i > 10)                % Sample if statement
    disp('Larger than 10')   % Print given string

  elseif i < 0               % Parentheses are optional
    disp('Negative value') 
  else
    disp('Something else')
  end

end

[~,d] = myotherfunction(10,100)


%% Example loops are slow: 

m = 10000;
n = 1000;

A = rand(m,n);  
% Implementation using loops:
score = 0;
tic;

for i=1:m
  for j=1:n
    score = score + A(i,j);
   end
end
toc

% All this can be computed w/o any loop!
tic;
score = sum(A);        
toc









