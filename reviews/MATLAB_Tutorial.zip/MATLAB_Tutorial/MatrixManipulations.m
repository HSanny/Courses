clc
clear all

%% Basic Manipulation
a = rand(3,2)                % A 3x2 matrix
b = rand(2,4)                % A 2x4 matrix
c = a * b                    % Matrix product results in a 3x4 matrix

[m,n] = size(a)              % size of Matrix
[~,n] = size(b)


clear all
clc

a = [1 2; 3 4; 5 6]         % A 3x2 matrix
b = [5 6 7];                 % A 1x3 row vector
b * a                        % Vector-matrix product results in
                             %   a 1x2 row vector
c = [8; 9];                  % A 2x1 column vector
a * c                        % Matrix-vector product results in

                             %   a 3x1 column vector

a = [1 3 2; 6 5 4; 7 8 9]   % A 3x3 matrix
                              % Matrix inverse of a
eig(a)                       % Vector of eigenvalues of a
[V, D] = eig(a)              % D matrix with eigenvalues on diagonal;
                             %   V matrix of eigenvectors

                          
                             %   Example for multiple return values!
[U, S, V] = svd(a)           % Singular value decomposition of a.
                             %   a = U * S * V', singular values are
                             %   stored in S

clear all
clc

%% Individual Row or Element wise manipulation
clear all
clc

a = [1 2; 3 4; 5 6]
a(1,2) = 10;                   % Individual Element
a
a(1,:) = [10 10];              % Row 
a
a(:,1) = [1 1 1]';             % Column
a

b = a.^2                       % sqaure each element

a.*b                            % Element wise manipulation

Z = 1./(1+exp(-a))              % complicated functions


%% Matrix Statistics
clear all
clc
a = [1 2; 3 4; 5 6]          % A 3x2 matrix

sum(a(:))                    % Useful:  sum of all elements

sum(a)                       % By default column wise sum
sum(a,2)                     % Row wise sum

mean(a)                      % mean
mean(a,2)

max(a)                       % max
max(a,2)
max(max(a)) 

clc

sort(a)
sort(a,2)
[~,ind] = sort(a,'descend')         % Very useful 

clc
clear all

% You want to put all entries less than 0.5 to 0.

a = rand(4,4)
a(find(a<0.5)) = 0


%% Reshaping and assembling matrices:
clc
clear all
a = [1 2; 3 4; 5 6]          % A 3x2 matrix
a'                           % Transpose
b = a(:)                     % Make 6x1 column vector by stacking 
                             %   up columns of a

clc

a = reshape(b, 2, 3)         % Make 2x3 matrix out of vector 
                             %   elements (column-wise)

clc
clear all
                             
                             
a = [1 2]
b = [3 4]                    % Two row vectors
c = [a b]                    % Horizontal concatenation (see horzcat)

clc
clear all

a = [1; 2; 3]                % Column vector

c = [a; 4]                   % Vertical concatenation (see vertcat)

clear all

a = [eye(3) rand(3)]         % Concatenation for matrices
b = [eye(3); ones(1, 3)]

b = repmat(5, 3, 2)          % Create a 3x2 matrix of fives
b = repmat([1 2; 3 4], 1, 2) % Replicate the 2x2 matrix twice in
                             %   column direction; makes 2x4 matrix
b = diag([1 2 3])            % Create 3x3 diagonal matrix with given

                             %   diagonal elements
%% See how easily you can standardize

A = rand(10000,100);
A = (A - repmat(mean(A),size(A,1),1))./repmat(std(A),size(A,1),1);

 


