%% Plotting

x = [0 1 2 3 4];             % Basic plotting
plot(x);                     % Plot x versus its index values
                        % Wait for key press
plot(x, 2*x);                % Plot 2*x versus x
axis([0 8 0 8]);             % Adjust visible rectangle

figure;                      % Open new figure
x = pi*[-24:24]/24;
plot(x, sin(x));
xlabel('radians');           % Assign label for x-axis
ylabel('sin value');         % Assign label for y-axis
title('dummy');              % Assign plot title

figure;                      
subplot(1, 2, 1);            % Multiple functions in separate graphs
plot(x, sin(x));             %   (see "help subplot")
axis square;                 % Make visible area square
subplot(1, 2, 2);
plot(x, 2*cos(x));
axis square;

close all

A = rand(1000,2);
C = ones(1000,1);

scatter(A(:,1),A(:,2));

C(find(A(:,1)>A(:,2))) = 2;

scatter(A(:,1),A(:,2),20,C,'fill');